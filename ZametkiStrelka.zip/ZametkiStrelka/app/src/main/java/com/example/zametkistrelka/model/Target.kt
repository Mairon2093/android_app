package com.example.zametkistrelka.model
import java.util.UUID


data class Target(
    val id: String = UUID.randomUUID().toString(),
    val imageResId: Int,
    val shots: List<Shot> = emptyList()
)