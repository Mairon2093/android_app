package com.example.zametkistrelka.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.zametkistrelka.R
import com.example.zametkistrelka.model.Note
import com.example.zametkistrelka.model.Target
import java.util.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNoteScreen(
    onSave: (Note) -> Unit,
    onCancel: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var targets by remember { mutableStateOf(emptyList<Target>()) }
    var editingTarget by remember { mutableStateOf<Target?>(null) }
    var showTargetDialog by remember { mutableStateOf(false) }

    val availableTargets = listOf(
        R.drawable.target_1 to "Мишень 1",
        R.drawable.target_2 to "Мишень 2"
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Новая заметка") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.ArrowBack, "Назад")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Текст заметки") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                maxLines = 10
            )

            // Блок мишеней
            if (targets.isNotEmpty()) {
                Text(
                    text = "Мишени:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(targets) { target ->
                        Box(
                            modifier = Modifier
                                .clickable {
                                    editingTarget = target
                                }
                        ) {
                            Image(
                                painter = painterResource(id = target.imageResId),
                                contentDescription = "Мишень",
                                modifier = Modifier.size(150.dp),
                                contentScale = ContentScale.Fit
                            )
                            // Бейдж с количеством пробоин
                            if (target.shots.isNotEmpty()) {
                                Text(
                                    text = "${target.shots.size}",
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .background(
                                            MaterialTheme.colorScheme.primaryContainer,
                                            CircleShape
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { showTargetDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Добавить мишень")
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            Note(
                                title = title,
                                description = description,
                                targets = targets
                            )
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сохранить заметку")
            }
        }
    }

    // Диалог выбора мишени
    if (showTargetDialog) {
        AlertDialog(
            onDismissRequest = { showTargetDialog = false },
            text = {
                Column {
                    availableTargets.forEach { (drawableId, desc) ->
                        Row(
                            modifier = Modifier
                                .clickable {
                                    targets = targets + Target(
                                        imageResId = drawableId // Автоматически генерируется UUID
                                    )
                                    showTargetDialog = false
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = drawableId),
                                contentDescription = desc,
                                modifier = Modifier.size(80.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(desc)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTargetDialog = false }) {
                    Text("Закрыть")
                }
            }
        )
    }

    // Редактор мишени
    editingTarget?.let { target ->
        TargetEditorScreen(
            target = target,
            onSave = { updatedTarget ->
                targets = targets.map {
                    if (it.id == target.id) updatedTarget else it
                }
                editingTarget = null
            },
            onClose = { editingTarget = null }
        )
    }
}