package com.example.zametkistrelka.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.zametkistrelka.R
import com.example.zametkistrelka.model.Shot
import com.example.zametkistrelka.model.Target
import kotlin.math.pow
import kotlin.math.sqrt
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.ui.layout.ContentScale


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TargetEditorScreen(
    target: Target,
    onSave: (Target) -> Unit,
    onClose: () -> Unit
) {
    var currentTarget by remember { mutableStateOf(target) }
    var selectedColor by remember { mutableStateOf(Color.Red) }

    val colors = listOf(
        Color.Red,
        Color.Blue,
        Color.Green,
        Color.Yellow,
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Редактор мишени") },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, "Закрыть")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        currentTarget = currentTarget.copy(shots = emptyList())
                    }) {
                        Icon(Icons.Default.Clear, "Очистить все")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Палитра цветов
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                colors.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(color)
                            .clickable { selectedColor = color }
                            .border(
                                width = 2.dp,
                                color = if (color == selectedColor) Color.White else Color.Transparent,
                                shape = CircleShape
                            )
                    )
                }
            }

            // Область мишени
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .padding(16.dp)
                    .background(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    )
            ) {
                // Изображение мишени
                Image(
                    painter = painterResource(id = currentTarget.imageResId),
                    contentDescription = "Мишень",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                // Слой для пробоин
                Canvas(modifier = Modifier.matchParentSize()) {
                    currentTarget.shots.forEach { shot ->
                        drawCircle(
                            color = shot.color,
                            center = shot.position,
                            radius = shot.radius
                        )
                    }
                }

                // Обработка касаний
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .pointerInput(Unit) {
                            detectTapGestures { tapOffset ->
                                val clickedShot = currentTarget.shots.firstOrNull { shot ->
                                    val distance = sqrt(
                                        (shot.position.x - tapOffset.x).pow(2) +
                                                (shot.position.y - tapOffset.y).pow(2)
                                    )
                                    distance < shot.radius * 1.1
                                }

                                currentTarget = if (clickedShot != null) {
                                    // Удаляем пробоину
                                    currentTarget.copy(
                                        shots = currentTarget.shots - clickedShot
                                    )
                                } else {
                                    // Добавляем новую пробоину
                                    currentTarget.copy(
                                        shots = currentTarget.shots + Shot(
                                            position = tapOffset,
                                            color = selectedColor,
                                            radius = 20f
                                        )
                                    )
                                }
                            }
                        }
                )
            }

            // Кнопка сохранения
            Button(onClick = { onSave(currentTarget) }) {
                Text("Сохранить")
            }
        }
    }
}