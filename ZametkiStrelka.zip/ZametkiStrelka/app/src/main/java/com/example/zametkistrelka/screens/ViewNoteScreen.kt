package com.example.zametkistrelka.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.zametkistrelka.R
import com.example.zametkistrelka.model.Note
import com.example.zametkistrelka.model.Shot
import com.example.zametkistrelka.model.Target
import java.text.SimpleDateFormat
import java.util.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewNoteScreen(
    note: Note,
    onSave: (Note) -> Unit,
    onBack: () -> Unit
) {
    var currentNote by remember { mutableStateOf(note) }
    var editingTarget by remember { mutableStateOf<Target?>(null) }
    var isEditing by remember { mutableStateOf(false) }
    var showAddTargetDialog by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }
    val availableTargets = listOf(
        R.drawable.target_1 to "Мишень 1",
        R.drawable.target_2 to "Мишень 2"
    )

    // Функция для обновления мишени
    fun updateTarget(updatedTarget: Target) {
        currentNote = currentNote.copy(
            targets = currentNote.targets.map {
                if (it.id == updatedTarget.id) updatedTarget else it
            }
        )
        // Сохраняем изменения сразу
        onSave(currentNote)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(text = if (isEditing) "Редактирование" else "Просмотр") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Назад")
                    }
                },
                actions = {
                    // Кнопка добавления мишени (всегда видна)
                    IconButton(onClick = { showAddTargetDialog = true }) {
                        Icon(Icons.Default.Add, "Добавить мишень")
                    }
                    // Кнопка редактирования/сохранения
                    IconButton(onClick = {
                        if (isEditing) onSave(currentNote)
                        isEditing = !isEditing
                    }) {
                        Icon(
                            Icons.Default.Edit,
                            if (isEditing) "Сохранить" else "Редактировать"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            if (isEditing) {
                // Режим редактирования заметки
                OutlinedTextField(
                    value = currentNote.title,
                    onValueChange = { currentNote = currentNote.copy(title = it) },
                    label = { Text("Название") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = currentNote.description,
                    onValueChange = { currentNote = currentNote.copy(description = it) },
                    label = { Text("Текст заметки") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    maxLines = 10
                )
            } else {
                // Режим просмотра заметки
                Text(
                    text = currentNote.title,
                    style = MaterialTheme.typography.headlineSmall
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = dateFormat.format(currentNote.date),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = currentNote.description,
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            // Блок мишеней (одинаковый для обоих режимов)
            if (currentNote.targets.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Мишени:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(currentNote.targets) { target ->
                        Box(
                            modifier = Modifier
                                .clickable { editingTarget = target } // Редактируем по клику в любом режиме
                        ) {
                            Image(
                                painter = painterResource(id = target.imageResId),
                                contentDescription = "Мишень",
                                modifier = Modifier.size(150.dp),
                                contentScale = ContentScale.Fit
                            )
                            if (target.shots.isNotEmpty()) {
                                Text(
                                    text = "${target.shots.size}",
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .background(
                                            MaterialTheme.colorScheme.primaryContainer,
                                            CircleShape
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                }
            }
        }
    }

    // Диалог добавления мишени
    if (showAddTargetDialog) {
        AlertDialog(
            onDismissRequest = { showAddTargetDialog = false },
            title = { Text("Добавить мишень") },
            text = {
                Column {
                    availableTargets.forEach { (drawableId, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    currentNote = currentNote.copy(
                                        targets = currentNote.targets + Target(imageResId = drawableId)
                                    )
                                    showAddTargetDialog = false
                                    onSave(currentNote) // Сохраняем сразу
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = drawableId),
                                contentDescription = desc,
                                modifier = Modifier.size(80.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(desc)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddTargetDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    // Редактор мишени (работает в обоих режимах)
    editingTarget?.let { target ->
        TargetEditorScreen(
            target = target,
            onSave = { updatedTarget ->
                updateTarget(updatedTarget) // Сохраняем изменения
                editingTarget = null
            },
            onClose = { editingTarget = null }
        )
    }
}