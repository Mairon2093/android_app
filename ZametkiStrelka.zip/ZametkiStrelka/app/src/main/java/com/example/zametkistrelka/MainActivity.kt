package com.example.zametkistrelka

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.zametkistrelka.model.Note
import com.example.zametkistrelka.screens.AddNoteScreen
import com.example.zametkistrelka.screens.ViewNoteScreen
import com.example.zametkistrelka.ui.theme.ZametkiStrelkaTheme
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.clickable

val builtInTargets = listOf(
    Pair(R.drawable.target_1, "Мишень №4 (Стандарт)"),
    Pair(R.drawable.target_2, "Мишень-Силуэт (Олимпийка)")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ZametkiStrelkaTheme {
                NotesApp()
            }
        }
    }
}

@Composable
fun NotesApp() {
    var notes by remember { mutableStateOf(emptyList<Note>()) }
    var showAddScreen by remember { mutableStateOf(false) }
    var currentNote by remember { mutableStateOf<Note?>(null) } // Для открытия деталей заметки

    // Навигация между экранами
    when {
        currentNote != null -> {
            ViewNoteScreen(
                note = currentNote!!,
                onSave = { updatedNote ->
                    notes = notes.map { if (it.id == updatedNote.id) updatedNote else it }
                    currentNote = updatedNote // <- Не закрываем экран, только обновляем данные
                },
                onBack = { currentNote = null } // Закрытие только по явному возврату
            )
        }
        showAddScreen -> {
            AddNoteScreen(
                onSave = { newNote ->
                    notes = notes + newNote
                    showAddScreen = false
                },
                onCancel = { showAddScreen = false }
            )
        }
        else -> {
            MainScreen(
                notes = notes,
                onAddNote = { showAddScreen = true },
                onNoteClick = { note -> currentNote = note }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    notes: List<Note>,
    onAddNote: () -> Unit,
    onNoteClick: (Note) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Заметки стрелка") },
                actions = {
                    IconButton(onClick = onAddNote) {
                        Icon(Icons.Default.Add, contentDescription = "Добавить")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            if (notes.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Нажмите + чтобы добавить заметку")
                }
            } else {
                NotesList(notes = notes, onNoteClick = onNoteClick)
            }
        }
    }
}

@Composable
fun NotesList(
    notes: List<Note>,
    onNoteClick: (Note) -> Unit
) {
    val sortedNotes = notes.sortedByDescending { it.date }
    val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    LazyColumn {
        items(sortedNotes) { note ->
            NoteItem(
                note = note,
                dateFormat = dateFormat,
                onClick = { onNoteClick(note) }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun NoteItem(
    note: Note,
    dateFormat: SimpleDateFormat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = dateFormat.format(note.date),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
    }
}