package com.example.zametkistrelka.model

import java.util.*

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val date: Date = Date(),
    val targets: List<Target> = emptyList() // Основное хранилище мишеней
)