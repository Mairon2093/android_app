package com.example.zametkistrelka.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

data class Shot(
    val position: Offset,
    val color: Color,
    val radius: Float
)